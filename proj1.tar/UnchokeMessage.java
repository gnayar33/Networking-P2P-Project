
public class UnchokeMessage extends Message
{
	public UnchokeMessage()
	{
		super((byte) 1);
	}
}
