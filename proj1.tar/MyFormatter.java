import java.util.logging.*;

public class MyFormatter extends Formatter{
	@Override
	public String format(LogRecord record){
		long millis = record.getMillis();
		long second = (millis / 1000) % 60;
		long minute = (millis / (1000 * 60)) % 60;
		long hour = (millis / (1000 * 60 * 60)) % 12 - 4;
		String time = String.format("%02d:%02d", hour, minute);
		return time+"\t"+record.getMessage()+"\n";
	}
}