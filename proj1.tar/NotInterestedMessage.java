
public class NotInterestedMessage extends Message
{
	public NotInterestedMessage()
	{
		super((byte) 3);
	}
}
