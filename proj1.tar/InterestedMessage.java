
public class InterestedMessage extends Message
{
	public InterestedMessage()
	{
		super((byte) 2);
	}
}
