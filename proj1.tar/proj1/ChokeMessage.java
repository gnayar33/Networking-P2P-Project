
public class ChokeMessage extends Message
{
	public ChokeMessage()
	{
		super((byte) 0);
	}
	
}
